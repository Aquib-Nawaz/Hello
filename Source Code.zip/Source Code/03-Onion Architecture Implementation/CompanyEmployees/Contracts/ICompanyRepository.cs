﻿namespace Contracts;

public interface ICompanyRepository
{
}
